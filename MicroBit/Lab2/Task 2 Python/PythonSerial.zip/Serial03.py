import serial
import tkinter   # The python tcl/tk ui construction api

top = tkinter.Tk()     # The tcl/tk object
canvas = tkinter.Canvas(top,bg="bisque",height=800,width=800)
canvas.pack()
top.update()

ser = serial.Serial()
ser.baudrate = 115200
ser.bytesize = 8
ser.stopbits = 1
ser.parity = 'N'
ser.timeout = 5
ser.port = "com7"
ser.xonxoff = 0
ser.rtscts = 0
ser.open()

def readLine():
  line = ""
  while True:
    x = ser.read(1)
    if x.__len__() > 0:
      if chr(x[0]) == '\r':
        return line
      else:
        line += chr(x[0])
        
t = 0
lastX = 0
while True:
  x = int(readLine()) / 5
  canvas.create_line(t, 400 + lastX, t + 1, 400 + x, fill="red")
  lastX = x
  t += 1
  top.update()
  if t > 800:
    t = 0
    canvas.delete("all")
