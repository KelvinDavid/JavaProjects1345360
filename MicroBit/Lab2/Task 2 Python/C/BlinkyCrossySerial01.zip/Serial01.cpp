#include "MicroBit.h"

MicroBit uBit;

int main() {
  uBit.init();
  for (;;) {
	int x = uBit.accelerometer.getX();
	uBit.serial.send(ManagedString(x)+"\n\r");
  }
}
