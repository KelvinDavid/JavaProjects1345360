#include "MicroBit.h"

MicroBit uBit;

int main() {
  uBit.init();

  uint8_t buffer[10];  // Bigger than needed

  for (;;) {
	int x = uBit.accelerometer.getX();
     *((int *)buffer) = x;
     uBit.serial.send(buffer, 4);
	}
}
